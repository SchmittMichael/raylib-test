#ifndef SUB_H
#define SUB_H

int sub(void);

#endif
