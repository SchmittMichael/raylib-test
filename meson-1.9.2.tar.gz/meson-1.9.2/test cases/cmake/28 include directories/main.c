#include <stdint.h>
#include <cmTest.h>

int main(void)
{
    cmTestFunc();
    return 0;
}

